# HTML Loader

Carrega os dados do servidor e insere o HTML retornado em um elemento no DOM.

### **Testes**

---

- Fetch API
- XMLHttpRequest
- jQuery
  - get
  - load

### **Autor**

---

Rafael Carls
