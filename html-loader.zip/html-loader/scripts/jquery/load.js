const renderPartial = (id) => {
    $("div").load(`../../view/partial-${id}.html`);
};